# ConsensusAlign — arXiv preprint

Compile **main.tex** with **pdfLaTeX, TeX Live 2023**. It produces a single
PDF containing the signed main paper, references and the complete supplement.
All six authors share the affiliation **The University of Sydney**.

The included `00README.json` requests these settings for arXiv. TeX Live 2023
is selected because arXiv documents a cleveref compatibility issue in its
TeX Live 2025 distribution:
https://info.arxiv.org/help/faq/texlive.html#usage-of-cleveref-package

`main.bbl` is pre-generated and matches `main.tex`. `main.bib` and the bibliography
style are retained so references can be regenerated after edits. Local compilation:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

Upload the source ZIP as an Overleaf project, or as the source submission to arXiv.
In Overleaf, set the main document to `main.tex` and choose TeX Live 2023.
The package contains only the document and its dependencies. The PDF is provided
separately for inspection. The anonymous submission project is a separate source.
